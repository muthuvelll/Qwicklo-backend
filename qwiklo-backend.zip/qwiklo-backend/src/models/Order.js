const mongoose = require('mongoose');

const orderSchema = new mongoose.Schema({
  orderNumber: { type: String, unique: true },
  user: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
  items: [{
    product:    { type: mongoose.Schema.Types.ObjectId, ref: 'Product', required: true },
    name:       String,   // snapshot at time of order
    price:      Number,
    emoji:      String,
    quantity:   { type: Number, required: true, min: 1 },
  }],
  shippingAddress: {
    line1:    { type: String, required: true },
    city:     { type: String, required: true },
    state:    String,
    pincode:  String,
    country:  { type: String, default: 'IN' },
  },
  subtotal:     { type: Number, required: true },
  deliveryFee:  { type: Number, default: 0 },
  total:        { type: Number, required: true },
  status: {
    type: String,
    enum: ['pending','confirmed','processing','shipped','delivered','cancelled'],
    default: 'pending'
  },
  payment: {
    method:     { type: String, default: 'razorpay' },
    paymentId:  String,
    status:     { type: String, enum: ['pending','paid','failed'], default: 'pending' },
    paidAt:     Date,
  },
  notes:        String,
}, { timestamps: true });

// Auto-generate order number
orderSchema.pre('save', async function(next) {
  if (!this.orderNumber) {
    const count = await mongoose.model('Order').countDocuments();
    this.orderNumber = 'QWK' + String(count + 1001).padStart(5, '0');
  }
  next();
});

module.exports = mongoose.model('Order', orderSchema);
