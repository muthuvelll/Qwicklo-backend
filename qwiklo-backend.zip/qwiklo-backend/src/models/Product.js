const mongoose = require('mongoose');

const productSchema = new mongoose.Schema({
  name:               { type: String, required: true, trim: true },
  description:        { type: String, required: true },
  price:              { type: Number, required: true, min: 0 },
  compareAtPrice:     { type: Number },           // original/MRP price
  category:           { type: String, required: true, enum: ['beauty','tech','home','fitness','fashion','books','pet','food'] },
  emoji:              { type: String, default: '📦' },
  images:             [{ type: String }],
  highlights:         [{ type: String }],
  stock:              { type: Number, default: 100, min: 0 },
  badge:              { type: String },           // e.g. "Bestseller", "56% off"
  badgeType:          { type: String, enum: ['sale','new','hot'], default: 'new' },
  rating:             { type: Number, default: 4.5, min: 0, max: 5 },
  reviewCount:        { type: Number, default: 0 },
  discountPercentage: { type: Number, default: 0 },
  delivery:           { type: Boolean, default: true }, // free delivery
  isActive:           { type: Boolean, default: true },
}, { timestamps: true });

// Auto-calculate discount percentage before saving
productSchema.pre('save', function(next) {
  if (this.compareAtPrice && this.compareAtPrice > this.price) {
    this.discountPercentage = Math.round((1 - this.price / this.compareAtPrice) * 100);
    if (!this.badge) this.badge = `${this.discountPercentage}% off`;
  }
  next();
});

module.exports = mongoose.model('Product', productSchema);
