const User = require('../models/User');
const Product = require('../models/Product');

const sampleProducts = [
  { name: 'Electric Neck Massager', description: 'Relieve neck and shoulder tension in minutes. Features 6 massage nodes, 3 intensity levels, heat therapy, and USB rechargeable battery.', price: 899, compareAtPrice: 2499, category: 'home', emoji: '💆‍♀️', badge: 'Bestseller', badgeType: 'hot', rating: 4.8, reviewCount: 2347, highlights: ['6 deep-kneading nodes', 'Heat + vibration therapy', '3 intensity levels', 'USB rechargeable', 'Folds for travel'] },
  { name: 'LED Ring Light 10"', description: 'Professional studio lighting for reels, vlogs and video calls. 3 colour modes, 10 brightness levels, phone holder and 160cm tripod included.', price: 549, compareAtPrice: 1299, category: 'tech', emoji: '💡', badgeType: 'sale', rating: 4.7, reviewCount: 1892, highlights: ['3 colour modes', '10 brightness levels', 'Phone holder included', '160cm tripod'] },
  { name: 'Vitamin C Face Serum', description: 'Brighten dull skin and fade dark spots with 20% stable Vitamin C, Hyaluronic Acid, and Niacinamide. Lightweight, non-greasy. Dermatologist tested.', price: 649, compareAtPrice: 1499, category: 'beauty', emoji: '🧴', badgeType: 'sale', rating: 4.9, reviewCount: 4120, highlights: ['20% Vitamin C', 'Hyaluronic Acid + Niacinamide', 'Fades dark spots in 4 weeks', 'All skin types'] },
  { name: 'Foldable Phone Stand', description: 'Sturdy aluminium stand with 270° angle adjustment. Holds phones and tablets up to 12". Anti-slip pads. Folds to credit-card thickness.', price: 299, compareAtPrice: 799, category: 'tech', emoji: '📱', badge: 'New', badgeType: 'new', rating: 4.5, reviewCount: 1560, delivery: false },
  { name: 'Yoga Mat + Strap', description: '6mm thick anti-slip yoga mat from eco-friendly TPE. Double-layer construction cushions joints. Free carry strap. 183×61cm.', price: 799, compareAtPrice: 1799, category: 'fitness', emoji: '🧘‍♀️', badgeType: 'sale', rating: 4.6, reviewCount: 982, highlights: ['6mm TPE cushioning', 'Eco-friendly', '183×61cm', 'Free carry strap'] },
  { name: 'Pet Grooming Brush', description: 'Self-cleaning slicker brush removes fur in one stroke. One-click retract clears fur instantly. Vet recommended for dogs and cats.', price: 449, compareAtPrice: 999, category: 'pet', emoji: '🐾', badge: 'New', badgeType: 'new', rating: 4.9, reviewCount: 674, delivery: false },
  { name: 'Wireless Earbuds Pro', description: '13mm drivers, Active Noise Cancellation, 30-hour total battery. IPX5 water resistant. Pairs to 2 devices. 40-min fast charge.', price: 1299, compareAtPrice: 3499, category: 'tech', emoji: '🎧', badgeType: 'sale', rating: 4.8, reviewCount: 5892, highlights: ['Active Noise Cancellation', '30hr total battery', 'IPX5 water resistant', 'Dual device pairing'] },
  { name: 'Glow Skincare Kit', description: 'Complete 5-step glow routine: cleanser, toning mist, Vitamin C serum, moisturiser, SPF 50 sunscreen. Dermatologist curated.', price: 849, compareAtPrice: 1799, category: 'beauty', emoji: '✨', badgeType: 'sale', rating: 4.9, reviewCount: 3012, highlights: ['5 products in 1 kit', 'SPF 50 included', 'Results in 3 weeks'] },
  { name: 'Bamboo Cutting Board', description: 'Premium organic bamboo with built-in juice groove, non-slip feet, and hanging hole. Naturally antibacterial. 45×30cm.', price: 599, compareAtPrice: 1299, category: 'home', emoji: '🪵', badge: 'Eco Pick', badgeType: 'new', rating: 4.6, reviewCount: 882 },
  { name: 'Resistance Bands Set', description: '5 colour-coded resistance bands (5–40kg range). 100% natural latex. Carry bag and exercise guide included.', price: 349, compareAtPrice: 799, category: 'fitness', emoji: '🏋️', badgeType: 'sale', rating: 4.7, reviewCount: 1430, delivery: false },
];

module.exports = async (mongoose) => {
  try {
    // Create admin if not exists
    const adminEmail = process.env.ADMIN_EMAIL || 'admin@qwiklo.com';
    const existingAdmin = await User.findOne({ email: adminEmail });
    if (!existingAdmin) {
      await User.create({
        firstName: 'Qwiklo',
        lastName: 'Admin',
        email: adminEmail,
        password: process.env.ADMIN_PASSWORD || 'Admin@123',
        role: 'admin',
      });
      console.log(`✅ Admin created: ${adminEmail}`);
    }

    // Seed products if none exist
    const productCount = await Product.countDocuments();
    if (productCount === 0) {
      await Product.insertMany(sampleProducts);
      console.log(`✅ ${sampleProducts.length} sample products seeded`);
    }
  } catch (err) {
    console.error('Seed error:', err.message);
  }
};
