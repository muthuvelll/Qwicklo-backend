# 🚀 Qwiklo Backend API

Complete Node.js + Express + MongoDB backend for Qwiklo e-commerce app.

---

## 📋 API Endpoints

### Auth
| Method | Endpoint | Description |
|--------|----------|-------------|
| POST | `/api/v1/auth/register` | Create account |
| POST | `/api/v1/auth/login` | Login |
| GET | `/api/v1/auth/me` | Get current user |
| PATCH | `/api/v1/auth/me` | Update profile |
| PATCH | `/api/v1/auth/change-password` | Change password |

### Products
| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | `/api/v1/products` | Get all products |
| GET | `/api/v1/products?category=beauty` | Filter by category |
| GET | `/api/v1/products?search=serum` | Search products |
| GET | `/api/v1/products/:id` | Get single product |
| POST | `/api/v1/products` | Add product (admin) |
| PATCH | `/api/v1/products/:id` | Update product (admin) |
| DELETE | `/api/v1/products/:id` | Remove product (admin) |

### Orders
| Method | Endpoint | Description |
|--------|----------|-------------|
| POST | `/api/v1/orders` | Place order |
| GET | `/api/v1/orders/my` | My orders |
| GET | `/api/v1/orders/:id` | Order details |
| POST | `/api/v1/orders/razorpay/create` | Create Razorpay payment |

### Admin
| Method | Endpoint | Description |
|--------|----------|-------------|
| GET | `/api/v1/admin/dashboard` | Stats & overview |
| GET | `/api/v1/admin/orders` | All orders |
| PATCH | `/api/v1/admin/orders/:id/status` | Update order status |
| GET | `/api/v1/admin/users` | All users |
| PATCH | `/api/v1/admin/users/:id/toggle` | Enable/disable user |

---

## ⚙️ Setup Instructions

### Step 1 — Install Node.js
Download from https://nodejs.org (choose LTS version)

### Step 2 — Get Free MongoDB
1. Go to https://cloud.mongodb.com
2. Create free account
3. Create a free cluster (M0)
4. Click "Connect" → get your connection string
5. It looks like: `mongodb+srv://username:password@cluster0.xxxxx.mongodb.net/qwiklo`

### Step 3 — Setup the project
```bash
# Extract the zip / open the folder
cd qwiklo-backend

# Install dependencies
npm install

# Copy environment file
cp .env.example .env

# Edit .env with your details
# - Add your MongoDB URI
# - Add your Razorpay keys
# - Change JWT_SECRET to something random
```

### Step 4 — Run locally
```bash
npm run dev
```
Open http://localhost:3000 — you should see: `🚀 Qwiklo API is running!`

### Step 5 — Deploy to Railway (FREE)
1. Go to https://railway.app
2. Sign up with GitHub
3. Click "New Project" → "Deploy from GitHub repo"
4. Upload your code to GitHub first (or use Railway CLI)
5. Add environment variables in Railway dashboard
6. Your API will be live at: `https://qwiklo-backend.up.railway.app`

### Step 6 — Connect to Frontend
In your `qwiklo.html`, update:
```js
const CONFIG = {
  BACKEND_URL: 'https://your-railway-url.up.railway.app/api/v1',
  RAZORPAY_KEY: 'rzp_live_XXXXXXXXXX',  // your real key
}
```

---

## 🔐 Default Admin Login
- Email: `admin@qwiklo.com`
- Password: `Admin@123`

**Change these in your `.env` file before going live!**

---

## 📦 Tech Stack
- **Node.js** + **Express** — server
- **MongoDB** + **Mongoose** — database
- **JWT** — authentication
- **Razorpay** — payments
- **bcryptjs** — password hashing
